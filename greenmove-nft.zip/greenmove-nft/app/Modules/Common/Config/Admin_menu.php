<?php

$ADMINMENU['update'] = array(
            'order'         => 100,
            'parent'        => display('update'),
            'status'        => 0,
            'link'          => 'auto_update',
            'icon'          => '<i class="fa fa-magic"></i>',
            'segment'       => 2,
            'segment_text'  => 'auto_update'
        );

 