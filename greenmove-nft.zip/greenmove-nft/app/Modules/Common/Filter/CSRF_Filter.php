<?php 

$filterdata[0] = array(
		'backend/auto_update/update',
		'backend/auto_update/updatenow'
    );