<?php

$ADMINMENU['auth'] = array(
    'order'         => 1,
    'parent'        => display('Dashboard'),
    'status'        => 0,
    'link'          => 'home',
    'icon'          => '<i class="fas fa-home"></i>',
    'segment'       => 2,
    'segment_text'  => 'home'
);